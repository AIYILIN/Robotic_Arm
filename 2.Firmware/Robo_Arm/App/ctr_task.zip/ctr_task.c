
#include "ctr_task.h"
#include "cmsis_os.h"
#include "ws2812.h"
#include "fdcan.h"
#include "can_bsp.h"
#include "string.h"
#include "can_bsp.h"
#include "cybergear.h"
#include "motor_pid.h"
#include "bsp_power_enable.h"
#include "imu_task.h"
#include "user_lib.h"
#include "key_task.h"
#include "bsp_ps2.h"
#include "BMI088Middleware.h"
#include "fun_test_task.h"
#include "bsp_arm.h"
#include "dma.h"
#include "bsp_buzzer.h"

// Ϊ6���ؽڸ��Դ��������Ĺ켣�滮��
TrapezoidalProfile joint_T_profilel[6];
SProfile joint_S_profilel[6];


void joint_T_profilel_param_init(TrapezoidalProfile *profile, float max_speed, float acceleration, float deceleration)
{
    for (int i = 0; i < 6; i++) 
    {
        joint_T_profilel[i].max_speed = max_speed;    
        joint_T_profilel[i].acceleration = acceleration;
        joint_T_profilel[i].deceleration = deceleration;
    }
        joint_T_profilel[0].target_pos = 0;    //-3~3
        joint_T_profilel[1].target_pos = 25;    //-8~8
        joint_T_profilel[2].target_pos = 45;    //-4~14
        joint_T_profilel[3].target_pos = 0;    //-2.7~2.7
}

void joint_S_profilel_param_init(SProfile *profile, float max_vel, float max_acc, float max_jerk)
{
    // ��ʼ��S�����߲���
    for (int i = 0; i < 6; i++) {
        joint_S_profilel[i].max_vel = 20.0f;      // ����ٶȣ�rad/s��
        joint_S_profilel[i].max_acc = 10.0f;      // �����ٶȣ�rad/s?��
        joint_S_profilel[i].max_jerk = 5.0f;     // ���Ӽ��ٶȣ�rad/s?��
        joint_S_profilel[i].target_pos = arm_joint[i].pos;
        joint_S_profilel[i].current_pos = arm_joint[i].pos;
        joint_S_profilel[i].current_vel = 0;
        joint_S_profilel[i].current_acc = 0;
        joint_S_profilel[i].phase = 0;
        joint_S_profilel[i].distance_updata_flag = 1;
        
    } 
    // ��ʼ��Ŀ��λ��
        joint_S_profilel[0].target_pos = 0;    //-3~3
        joint_S_profilel[1].target_pos = 25;    //-8~8
        joint_S_profilel[2].target_pos = 45;    //-4~14
}


void Update_T_Profile(TrapezoidalProfile *profile, float dt) 
{
    float remaining = profile->target_pos - profile->current_pos;
    float direction = (remaining > 0) ? 1.0f : -1.0f;
    float speed = 0;

    // ���㵱ǰ�׶Σ����١����١����٣�
    float decel_distance = (profile->max_speed * profile->max_speed) / (2 * profile->deceleration);//v^2 - 0^2 = 2*a*s
    if (fabs(remaining) <= decel_distance) {
        // ���ٽ׶�
        speed = sqrtf(2 * profile->deceleration * fabs(remaining)) * direction;
    } else {
        // ���ٻ����ٽ׶�
        speed = profile->max_speed * direction;
    }

    // ����λ��
    profile->current_pos += speed * dt;
}

void Update_S_Profile(SProfile *profile, float dt) {
    // 1. ��̬Ŀ����
    if (profile->target_pos != profile->last_target_pos) {
        float new_dir = (profile->target_pos > profile->current_pos) ? 1.0f : -1.0f;
        float old_dir = (profile->last_target_pos > profile->current_pos) ? 1.0f : -1.0f;

        if (new_dir != old_dir) {
            profile->current_vel = 0;
            profile->current_acc = 0;
            profile->phase = PHASE_ACCEL_UP;
            profile->distance_updata_flag = 1;//������±�־λ
            
        } else {
            profile->current_acc = new_dir * profile->max_acc;
        }
        profile->last_target_pos = profile->target_pos;
    }

    // 2. �����˶�����
    profile->remaining = profile->target_pos - profile->current_pos;
    profile->direction = (profile->remaining > 0) ? 1.0f : -1.0f;
    
    // 3. ����һ���Ա���
    // if (profile->current_vel * direction < 0) profile->current_vel = 0;
    // if (profile->current_acc * direction < 0) profile->current_acc = 0;

    // 4. ʣ�������

    
    float decel_distance = profile->distance *0.5f;
    if (fabs(profile->remaining) < fabs(decel_distance) && profile->phase < PHASE_DECEL_UP) 
    {
        profile->current_acc = 0;
        profile->phase = PHASE_DECEL_UP;
        // BSP_Buzzer_Toggle();
    }

    // 5. �׶��߼�
    
    switch (profile->phase) {
        case PHASE_ACCEL_UP://0�Ӽ��ٽ׶�
            if(profile->distance_updata_flag == 1)//������±�־λ
            {
                profile->distance = profile->target_pos - profile->current_pos;
                profile->distance_updata_flag = 0;
            }

            profile->jerk = profile->max_jerk * profile->direction;
            if (profile->remaining < (fabs(profile->distance) * 0.9f) )
            {
                profile->phase = PHASE_ACCEL_STEADY;
            }
            break;

        case PHASE_ACCEL_STEADY://1�ȼ��ٽ׶�
            profile->jerk = 0;
            if (profile->remaining < (fabs(profile->distance) * 0.8f)) 
            {
                profile->phase = PHASE_ACCEL_DOWN;
            }
            break;

        case PHASE_ACCEL_DOWN://�����ٽ׶�
            profile->jerk = -profile->max_jerk * profile->direction;
            if (profile->current_vel * profile->direction >= profile->max_vel) {
                profile->phase = PHASE_CRUISE;
                profile->jerk = 0;
            }
            break;

        case PHASE_CRUISE://3���ٽ׶�
            profile->jerk = 0;
            profile->current_acc = 0;
            break;

        case PHASE_DECEL_UP://4�����ٽ׶�
            profile->jerk = -profile->max_jerk * profile->direction;
            if (fabs(profile->remaining) < (fabs(profile->distance) * 0.1f) || profile->current_acc * profile->direction <= -profile->max_acc) {
                profile->phase = PHASE_DECEL_STEADY;
            }
            break;

        case PHASE_DECEL_STEADY://5�ȼ��ٽ׶�
            profile->jerk = 0;
            if (fabs(profile->remaining) < (fabs(profile->distance) * 0.05f) )
            {
                profile->phase = PHASE_DECEL_DOWN;
            }
            break;

        case PHASE_DECEL_DOWN://6�������ٽ׶�
            profile->jerk = profile->max_jerk * profile->direction;
            if (fabs(profile->remaining) < 1 ) 
            {
                profile->current_pos = profile->target_pos;
                profile->current_vel = 0;
                profile->current_acc = 0;
                profile->phase = PHASE_FINISHED;
            }
            break;

        case PHASE_FINISHED:
            if(profile->target_pos != profile->current_pos) profile->phase = PHASE_ACCEL_UP;
            profile->distance_updata_flag = 1;
            break;
    }

    // 6. �����˶�״̬
    profile->current_acc += profile->jerk * dt;
    profile->current_vel += profile->current_acc * dt;
    profile->current_pos += profile->current_vel * dt;

    // 7. ����ǯλ
    if (fabs(profile->remaining) < 0.001f) {
        profile->current_pos = profile->target_pos;
        profile->current_vel = 0;
        profile->current_acc = 0;
    }
}




int debug_count = 0;
void CtrTask_Entry(void const * argument)
{
    HAL_UARTEx_ReceiveToIdle_DMA(&huart2, dma_rx_buffer, RX_BUFFER_SIZE);
    Power_Enable(); 
    
    osDelay(500);

for (;;) 
{
     // �������йؽڵĹ켣
    for (int i = 0; i < 6; i++) 
    {
    //   Update_T_Profile(&joint_profilel[i], 0.002f);  // dt=5ms
        Update_S_Profile(&joint_S_profilel[i], 0.003f);  // dt=5ms  
    }   

    debug_count++;
    if(debug_count % 10 == 0) 
    {
        char debug_buffer[200];
        sprintf(debug_buffer, "cur_pos=%4.2f,cur_vel=%4.2f,cur_acc=%4.2f,tar_pos=%4.2f,phase=%1d,distance=%4.2f,flag=%1d,jerk=%4.2f,remain=%4.2f,dir:%4.2f,max_vel=%4.2f,max_acc=%4.2f,max_jerk=%4.2f\r\n"
                ,joint_S_profilel[1].current_pos
                ,joint_S_profilel[1].current_vel
                ,joint_S_profilel[1].current_acc
                ,joint_S_profilel[1].target_pos
                ,joint_S_profilel[1].phase
                ,joint_S_profilel[1].distance
                ,joint_S_profilel[1].distance_updata_flag
                ,joint_S_profilel[1].jerk
                ,joint_S_profilel[1].remaining
                ,joint_S_profilel[1].direction
                ,joint_S_profilel[1].max_vel
                ,joint_S_profilel[1].max_acc
                ,joint_S_profilel[1].max_jerk);
        HAL_UART_Transmit(&huart1,(uint8_t*)debug_buffer,strlen(debug_buffer),100);
        debug_count = 0;
    }
        

    for (int i = 0; i < 6; i++) 
    {
      arm_joint[i].pos = joint_S_profilel[i].current_pos;     // ʹ��ƽ�����λ��
    }
    
    Arm_joints_control(arm_joint);
    osDelay(1);
}

    /* USER CODE END CtrTask_Entry */
}




